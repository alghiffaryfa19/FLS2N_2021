<?php

return [
    'zoom_level'           => 6,
    'detail_zoom_level'    => 9,
    'map_center_latitude'  => env('MAP_CENTER_LATITUDE', '-3.313695'),
    'map_center_longitude' => env('MAP_CENTER_LONGITUDE', '114.590148'),
];
